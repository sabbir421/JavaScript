var win=0;
var lost=0;

for(var i=1;i<=5;i++){
    var YourNumber =parseInt(prompt("enter your number"));
    var value = Math.floor(Math.random()*5)+1;
    if (value==YourNumber){
        win++;
        document.write("you win" +"<br>");
    }
    else{
        lost++;
        document.write("you win"+"<br>")
    }

}
document.write("total number of win :"+ win + "<br>");
document.write("number of lost :" + lost + "<br>");