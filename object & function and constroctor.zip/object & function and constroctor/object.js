function Score(name,ball,dot,run,)
{
    this.name = name;
    this.ball = ball;
    this.dot = dot;
    this.run = run;

    this.display=function()
    {
    document.write(this.name );
    document.write(this.ball );
    document.write(this.dot );
    document.write(this.run );
    }
}

var Tamim=new Score("Tamim ","150 ", "40 ","190","</br>");
var Liton=new Score("</br> Liton ","15 ","09 ","09","</br>");
var Musfiq=new Score("</br> Musfiq ","50 ","10 ","60");
var Sakib=new Score(" </br> Sakib","  80 " , "20 ","90");

Tamim.display();
Liton.display();
Musfiq.display();
Sakib.display();
